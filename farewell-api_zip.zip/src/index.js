import React from "react";
import ReactDom from "react-dom";

ReactDom.render(
    <div>
<h1>hello world</h1>
    </div>,document.getElementById("root")
);
